// pages exporting file

export { HomePage } from "./HomePage";
