import React from "react";

export const Header = () => {
  return (
    <div className="h-[4rem] bg-[#3f404a] flex justify-center items-center">
      <div className="flex justify-center items-center">HH</div>
    </div>
  );
};
